# 💰 Lucrei - Sistema de Gestão Financeira

Sistema completo de gestão financeira para MEI e pequenas empresas, com controle de contas a pagar e receber, fluxo de caixa, conciliação bancária, faturas e relatórios em tempo real.

## 🚀 Funcionalidades

- ✅ **Contas a Pagar e Receber** - Gestão completa de receitas e despesas
- 📊 **Dashboard Interativo** - Gráficos e métricas em tempo real
- 💸 **Fluxo de Caixa** - Controle detalhado de entradas e saídas
- 🏦 **Conciliação Bancária** - Importação e conciliação de extratos OFX
- 📄 **Faturas** - Emissão e controle de faturas
- 👥 **Gestão de Contatos** - Clientes e fornecedores
- 📈 **Relatórios** - Exportação em PDF e Excel
- 🔔 **Notificações em Tempo Real** - WebSocket para alertas
- 📱 **100% Responsivo** - Otimizado para mobile
- 🔒 **Seguro** - Autenticação JWT e criptografia

## 📁 Estrutura do Projeto

```
lucrei/
├── client/                    # Frontend React + Vite
│   ├── src/
│   │   ├── components/       # Componentes reutilizáveis
│   │   ├── pages/           # Páginas da aplicação
│   │   ├── hooks/           # Custom hooks
│   │   ├── lib/             # Utilidades e configurações
│   │   └── styles/          # Estilos CSS
│   └── index.html
├── server/                    # Backend Express + PostgreSQL
│   ├── db-storage.ts        # Camada de dados (PostgreSQL)
│   ├── websocket.ts         # Servidor WebSocket
│   ├── index.ts             # Servidor principal
│   ├── middlewares/         # Middlewares (auth, upload, etc)
│   ├── utils/               # Utilidades (reports, backup, etc)
│   └── uploads/             # Arquivos enviados
├── shared/                    # Código compartilhado
│   └── schema.ts            # Schemas Drizzle ORM
└── package.json
```

## 🔧 Tecnologias Utilizadas

### Frontend
- React 18, TypeScript, Vite, Tailwind CSS
- Wouter (roteamento), Recharts (gráficos), Framer Motion
- Radix UI (componentes acessíveis)

### Backend
- Express, PostgreSQL, Drizzle ORM
- WebSocket, Passport.js, Multer, PDFKit, XLSX

## 🚀 PASSO A PASSO - Como Rodar o Sistema

### ✅ OPÇÃO 1: Rodar no Replit (MAIS FÁCIL - GRÁTIS)

#### Passo 1: Criar Conta no Replit
1. Acesse: **https://replit.com**
2. Clique em **"Sign up"** (se não tiver conta)
3. Use Google, GitHub ou Email para criar conta gratuita

#### Passo 2: Importar Este Projeto
1. No Replit, clique em **"+ Create Repl"**
2. Escolha **"Import from GitHub"**
3. Cole a URL do repositório do projeto
4. Clique em **"Import from GitHub"**
5. Aguarde o Replit configurar tudo automaticamente

#### Passo 3: Configurar Banco de Dados
1. No painel esquerdo, clique em **"Tools"** (ícone de chave 🔧)
2. Selecione **"PostgreSQL"**
3. Clique em **"Create database"**
4. ✅ Pronto! A variável `DATABASE_URL` é criada automaticamente

#### Passo 4: Configurar Secrets (Chaves de Segurança)
1. No painel esquerdo, clique em **"Tools"** (🔧)
2. Selecione **"Secrets"**
3. Adicione estas 3 secrets (uma por vez):

**Secret 1:**
- Key: `JWT_SECRET`
- Value: `minha-chave-super-secreta-jwt-2024`

**Secret 2:**
- Key: `ENCRYPTION_KEY`
- Value: `chave-de-32-caracteres-exatos!`

**Secret 3:**
- Key: `SESSION_SECRET`
- Value: `minha-sessao-secreta-forte-aqui`

**💡 DICA**: Em produção, gere chaves fortes! Use este comando no Shell:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

#### Passo 5: Rodar o Projeto
1. Clique no botão verde **"Run"** ▶️ no topo
2. Aguarde instalar as dependências (primeira vez demora ~2 minutos)
3. Quando aparecer "serving on port 5000", está pronto!
4. Clique no preview do lado direito ou abra a URL completa

#### Passo 6: Fazer Login
**Credenciais padrão:**
- Usuário: `admin`
- Senha: `admin123`

**⚠️ IMPORTANTE**: Após entrar, vá em Configurações e altere a senha!

---

### ✅ OPÇÃO 2: Rodar Localmente (no seu computador)

#### Passo 1: Instalar Pré-requisitos
1. **Node.js 20+**: https://nodejs.org (baixe e instale)
2. **PostgreSQL**: https://www.postgresql.org/download (ou use Docker)
3. **Git**: https://git-scm.com (para clonar o projeto)

#### Passo 2: Clonar o Projeto
```bash
git clone <url-do-repositorio>
cd lucrei
```

#### Passo 3: Instalar Dependências
```bash
npm install
```

#### Passo 4: Configurar Banco de Dados PostgreSQL
Crie um banco chamado `lucrei`:
```bash
# No terminal do PostgreSQL
createdb lucrei
```

#### Passo 5: Criar Arquivo .env
Crie um arquivo chamado `.env` na raiz do projeto com:
```env
DATABASE_URL=postgresql://usuario:senha@localhost:5432/lucrei
JWT_SECRET=minha-chave-super-secreta-jwt-2024
ENCRYPTION_KEY=chave-de-32-caracteres-exatos!
SESSION_SECRET=minha-sessao-secreta-forte-aqui
```

#### Passo 6: Rodar o Sistema
```bash
npm run dev
```

Abra no navegador: **http://localhost:5000**

Login: `admin` / `admin123`

---

## 🌐 Como Publicar GRATUITAMENTE na Internet

### Método 1: Compartilhar Repl (Mais Simples)
1. No Replit, clique em **"Share"** (canto superior direito)
2. Copie o link (algo como: `https://lucrei.seunome.repl.co`)
3. Compartilhe! Qualquer pessoa pode acessar

### Método 2: Deploy Permanente no Replit
1. No Replit, clique em **"Deploy"** (no topo)
2. Escolha **"Autoscale deployment"**
3. Configure:
   - Build command: `npm run build`
   - Run command: `npm start`
4. Clique em **"Deploy"**
5. Você terá uma URL permanente!

**💰 Custo**: Replit tem plano gratuito limitado. Para uso contínuo, considere o plano pago (~$7/mês)

### Método 3: Deploy em Outros Serviços Gratuitos

#### Render.com (Recomendado para fullstack)
1. Crie conta em: **https://render.com**
2. Conecte seu GitHub
3. Clique em **"New +"** → **"Web Service"**
4. Selecione seu repositório
5. Configure:
   - Name: `lucrei`
   - Build Command: `npm install && npm run build`
   - Start Command: `npm start`
6. Adicione Environment Variables:
   - `DATABASE_URL` (do Render PostgreSQL - gratuito)
   - `JWT_SECRET`
   - `ENCRYPTION_KEY`
   - `SESSION_SECRET`
7. Clique em **"Create Web Service"**

#### Railway.app (Também excelente)
1. Acesse: **https://railway.app**
2. Clique em **"Start a New Project"**
3. Escolha **"Deploy from GitHub repo"**
4. Selecione seu repositório
5. Railway detecta tudo automaticamente
6. Adicione PostgreSQL no mesmo projeto
7. Configure as variáveis de ambiente
8. Deploy automático!

---

## 📱 Recursos Mobile

- ✅ Layout 100% responsivo
- ✅ Funciona perfeitamente em celulares e tablets
- ✅ Componentes otimizados para touch
- ✅ Sem cortes ou scroll horizontal
- ✅ Tabelas se transformam em cards no mobile
- ✅ Botões com tamanho ideal para toque (44x44px mínimo)

---

## 🔐 Segurança

- JWT para autenticação
- Senhas com Bcrypt
- CSRF Protection
- Rate Limiting
- Headers seguros (Helmet)
- Criptografia AES para dados sensíveis

---

## 📊 Funcionalidades Principais

### Dashboard
- Visão geral financeira
- Gráficos interativos
- Métricas em tempo real
- Alertas de vencimento

### Contas a Pagar/Receber
- Cadastro completo
- Categorização
- Status (pendente, pago, vencido)
- Filtros avançados
- Anexos de arquivos

### Fluxo de Caixa
- Projeções futuras
- Entradas vs Saídas
- Gráficos mensais
- Saldo atual e projetado

### Conciliação Bancária
- Importação de extratos OFX
- Conciliação automática
- Detecção de duplicatas
- Histórico completo

### Faturas
- Geração de faturas
- Envio por email
- Controle de status
- PDF profissional

### Relatórios
- Exportação PDF
- Exportação Excel
- Múltiplos períodos
- Gráficos personalizados

### Notificações
- Alertas em tempo real
- Vencimentos próximos
- Contas vencidas
- WebSocket real-time

---

## 🛠️ Comandos Úteis

```bash
npm run dev          # Desenvolvimento
npm run build        # Build produção
npm start           # Produção
npm run db:push     # Atualizar schema do banco
npm run db:studio   # Interface visual do banco
```

---

## ❓ Problemas Comuns

### "Erro ao conectar banco de dados"
- Verifique se `DATABASE_URL` está configurado
- Confirme que o PostgreSQL está rodando
- Teste a conexão com: `npm run db:push`

### "Erro 401 Unauthorized"
- Verifique se `JWT_SECRET` está configurado
- Faça logout e login novamente
- Limpe o cache do navegador

### "Página não carrega"
- Verifique se o servidor está rodando (porta 5000)
- Olhe os logs no console
- Tente reiniciar o workflow

### "Notificações não funcionam"
- WebSocket requer HTTPS em produção
- No Replit funciona automaticamente
- Localmente funciona em localhost

---

## 📞 Suporte

- Documentação Replit: https://docs.replit.com
- Documentação React: https://react.dev
- Documentação PostgreSQL: https://www.postgresql.org/docs

---

## 📄 Licença

Projeto open source - use como quiser!

---

**🎉 Pronto! Agora você tem um sistema financeiro completo rodando gratuitamente!**
