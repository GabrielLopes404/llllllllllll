import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Upload, X, Loader2, File } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface FileUploadProps {
  type: 'avatar' | 'anexo';
  onUploadComplete?: (path: string) => void;
  currentFile?: string | null;
  accept?: string;
}

export function FileUpload({ type, onUploadComplete, currentFile, accept }: FileUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(currentFile || null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: 'Erro',
        description: 'Arquivo muito grande. Tamanho máximo: 10MB',
        variant: 'destructive',
      });
      return;
    }

    setUploading(true);

    try {
      const formData = new FormData();
      formData.append(type, file);

      const response = await fetch(`/api/upload/${type}`, {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Erro ao fazer upload');
      }

      const data = await response.json();
      const filePath = type === 'avatar' ? data.avatar : data.anexo;
      
      setPreview(filePath);
      onUploadComplete?.(filePath);

      toast({
        title: 'Sucesso',
        description: 'Arquivo enviado com sucesso',
      });
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao fazer upload do arquivo',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };

  const handleRemove = () => {
    setPreview(null);
    onUploadComplete?.('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const isImage = preview && /\.(jpg|jpeg|png|gif|webp)$/i.test(preview);

  return (
    <div className="space-y-2">
      <Input
        ref={fileInputRef}
        type="file"
        accept={accept || (type === 'avatar' ? 'image/*' : '*')}
        onChange={handleFileChange}
        disabled={uploading}
        className="hidden"
        id={`file-upload-${type}`}
      />
      
      {preview ? (
        <div className="relative border rounded-lg p-4">
          {isImage ? (
            <img
              src={preview}
              alt="Preview"
              className={`${type === 'avatar' ? 'w-24 h-24 rounded-full mx-auto object-cover' : 'max-w-full h-auto max-h-48'}`}
            />
          ) : (
            <div className="flex items-center gap-2">
              <File className="w-8 h-8" />
              <span className="text-sm truncate">{preview}</span>
            </div>
          )}
          <Button
            variant="destructive"
            size="icon"
            className="absolute top-2 right-2 h-6 w-6"
            onClick={handleRemove}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      ) : (
        <Button
          variant="outline"
          className="w-full"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
        >
          {uploading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Enviando...
            </>
          ) : (
            <>
              <Upload className="w-4 h-4 mr-2" />
              {type === 'avatar' ? 'Enviar Avatar' : 'Enviar Anexo'}
            </>
          )}
        </Button>
      )}
    </div>
  );
}
