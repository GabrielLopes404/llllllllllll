import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface MobileWrapperProps {
  children: ReactNode;
  className?: string;
}

export function MobileWrapper({ children, className }: MobileWrapperProps) {
  return (
    <div className={cn(
      "w-full overflow-x-hidden",
      "px-4 py-3 md:px-6 md:py-4",
      "mobile-safe-area",
      className
    )}>
      {children}
    </div>
  );
}

export function MobileCard({ children, className }: MobileWrapperProps) {
  return (
    <div className={cn(
      "bg-card border border-card-border rounded-lg",
      "p-3 md:p-6",
      "shadow-sm",
      "w-full overflow-hidden",
      className
    )}>
      {children}
    </div>
  );
}

export function MobileGrid({ children, className }: MobileWrapperProps) {
  return (
    <div className={cn(
      "grid gap-3 md:gap-4",
      "grid-cols-1 md:grid-cols-2 lg:grid-cols-3",
      "w-full",
      className
    )}>
      {children}
    </div>
  );
}

export function MobileStack({ children, className }: MobileWrapperProps) {
  return (
    <div className={cn(
      "flex flex-col md:flex-row gap-2 md:gap-4",
      "w-full",
      className
    )}>
      {children}
    </div>
  );
}

export function MobileTable({ children, className }: MobileWrapperProps) {
  return (
    <div className={cn(
      "w-full overflow-x-auto mobile-scroll",
      "rounded-lg border border-border",
      className
    )}>
      <div className="min-w-full inline-block align-middle">
        {children}
      </div>
    </div>
  );
}
