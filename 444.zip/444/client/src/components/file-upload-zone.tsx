import { useState, useRef, DragEvent, ChangeEvent } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, File, X, CheckCircle2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface FileUploadZoneProps {
  accept?: string;
  maxSize?: number; // in MB
  multiple?: boolean;
  onFilesSelected: (files: File[]) => void;
  onUploadComplete?: (results: any[]) => void;
  onUploadError?: (error: string) => void;
  className?: string;
  disabled?: boolean;
  uploadEndpoint?: string;
  autoUpload?: boolean;
}

export function FileUploadZone({
  accept = "*/*",
  maxSize = 10,
  multiple = false,
  onFilesSelected,
  onUploadComplete,
  onUploadError,
  className,
  disabled = false,
  uploadEndpoint,
  autoUpload = false,
}: FileUploadZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploading, setUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFiles = (fileList: File[]): { valid: File[]; errors: string[] } => {
    const valid: File[] = [];
    const errors: string[] = [];
    const maxSizeBytes = maxSize * 1024 * 1024;

    fileList.forEach(file => {
      if (file.size > maxSizeBytes) {
        errors.push(`${file.name}: Arquivo muito grande (máx: ${maxSize}MB)`);
      } else if (accept !== "*/*") {
        const acceptedTypes = accept.split(',').map(t => t.trim());
        const fileExt = '.' + file.name.split('.').pop()?.toLowerCase();
        const fileType = file.type;
        
        const isAccepted = acceptedTypes.some(type => {
          if (type.startsWith('.')) {
            return fileExt === type;
          }
          if (type.endsWith('/*')) {
            return fileType.startsWith(type.replace('/*', ''));
          }
          return fileType === type;
        });

        if (!isAccepted) {
          errors.push(`${file.name}: Tipo de arquivo não suportado`);
        } else {
          valid.push(file);
        }
      } else {
        valid.push(file);
      }
    });

    return { valid, errors };
  };

  const handleFiles = (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;

    const filesArray = Array.from(fileList);
    const { valid, errors } = validateFiles(filesArray);

    if (errors.length > 0) {
      setUploadStatus('error');
      setErrorMessage(errors.join('\n'));
      onUploadError?.(errors.join('\n'));
      return;
    }

    setFiles(valid);
    setUploadStatus('idle');
    setErrorMessage('');
    onFilesSelected(valid);

    if (autoUpload && uploadEndpoint && valid.length > 0) {
      setTimeout(() => uploadFiles(), 300);
    }
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (!disabled) {
      setIsDragging(true);
    }
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (disabled) return;

    handleFiles(e.dataTransfer.files);
  };

  const handleFileInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    handleFiles(e.target.files);
  };

  const handleRemoveFile = (index: number) => {
    const newFiles = files.filter((_, i) => i !== index);
    setFiles(newFiles);
    if (newFiles.length === 0) {
      setUploadStatus('idle');
      setErrorMessage('');
    }
  };

  const handleClearAll = () => {
    setFiles([]);
    setUploadStatus('idle');
    setErrorMessage('');
    setUploadProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const uploadFiles = async () => {
    if (!uploadEndpoint || files.length === 0) return;

    setUploading(true);
    setUploadProgress(0);
    setUploadStatus('idle');

    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);
    });

    try {
      const xhr = new XMLHttpRequest();

      xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
          const progress = Math.round((e.loaded / e.total) * 100);
          setUploadProgress(progress);
        }
      });

      xhr.addEventListener('load', () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          const response = JSON.parse(xhr.responseText);
          setUploadStatus('success');
          setUploading(false);
          onUploadComplete?.(response);
        } else {
          const errorData = JSON.parse(xhr.responseText);
          const errorMsg = errorData.error || 'Erro ao fazer upload';
          setUploadStatus('error');
          setErrorMessage(errorMsg);
          setUploading(false);
          onUploadError?.(errorMsg);
        }
      });

      xhr.addEventListener('error', () => {
        setUploadStatus('error');
        setErrorMessage('Erro de rede ao fazer upload');
        setUploading(false);
        onUploadError?.('Erro de rede ao fazer upload');
      });

      xhr.addEventListener('abort', () => {
        setUploadStatus('error');
        setErrorMessage('Upload cancelado');
        setUploading(false);
        onUploadError?.('Upload cancelado');
      });

      xhr.open('POST', uploadEndpoint);
      xhr.send(formData);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido';
      setUploadStatus('error');
      setErrorMessage(errorMsg);
      setUploading(false);
      onUploadError?.(errorMsg);
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <div className={cn("space-y-4", className)}>
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={cn(
          "relative flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-8 transition-all duration-200",
          isDragging && !disabled && "border-primary bg-primary/5 scale-[1.02]",
          !isDragging && !disabled && "border-muted-foreground/25 hover:border-primary/50 hover:bg-accent/5",
          disabled && "opacity-50 cursor-not-allowed",
          uploadStatus === 'error' && "border-destructive/50 bg-destructive/5"
        )}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          onChange={handleFileInputChange}
          className="hidden"
          id="file-upload-input"
          disabled={disabled}
        />

        <AnimatePresence mode="wait">
          {uploadStatus === 'idle' && (
            <motion.div
              key="upload-idle"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col items-center text-center space-y-4"
            >
              <div className="p-4 rounded-full bg-primary/10">
                <Upload className="h-8 w-8 text-primary" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-semibold">
                  {isDragging ? "Solte os arquivos aqui" : "Arraste arquivos ou clique para selecionar"}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {accept !== "*/*" && `Formatos aceitos: ${accept}`}
                  {maxSize && ` • Tamanho máximo: ${maxSize}MB`}
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={disabled}
                className="shadow-md hover:shadow-lg transition-shadow"
              >
                Selecionar Arquivo{multiple ? 's' : ''}
              </Button>
            </motion.div>
          )}

          {uploadStatus === 'error' && (
            <motion.div
              key="upload-error"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col items-center text-center space-y-3"
            >
              <div className="p-4 rounded-full bg-destructive/10">
                <AlertCircle className="h-8 w-8 text-destructive" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-semibold text-destructive">Erro no upload</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-line">
                  {errorMessage}
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={handleClearAll}
                className="shadow-md"
              >
                Tentar Novamente
              </Button>
            </motion.div>
          )}

          {uploadStatus === 'success' && (
            <motion.div
              key="upload-success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col items-center text-center space-y-3"
            >
              <div className="p-4 rounded-full bg-success/10">
                <CheckCircle2 className="h-8 w-8 text-success" />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg font-semibold text-success">Upload concluído!</h3>
                <p className="text-sm text-muted-foreground">
                  {files.length} arquivo{files.length > 1 ? 's' : ''} enviado{files.length > 1 ? 's' : ''} com sucesso
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {uploading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm rounded-lg">
            <div className="w-64 space-y-2">
              <Progress value={uploadProgress} className="h-2" />
              <p className="text-sm text-center text-muted-foreground">
                Enviando... {uploadProgress}%
              </p>
            </div>
          </div>
        )}
      </div>

      {files.length > 0 && uploadStatus !== 'success' && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium">
              {files.length} arquivo{files.length > 1 ? 's' : ''} selecionado{files.length > 1 ? 's' : ''}
            </p>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleClearAll}
              className="text-muted-foreground hover:text-destructive"
            >
              <X className="h-4 w-4 mr-1" />
              Limpar tudo
            </Button>
          </div>
          <div className="space-y-2">
            {files.map((file, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="flex items-center justify-between p-3 rounded-lg border border-border bg-card hover:bg-accent/50 transition-colors"
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className="p-2 rounded-md bg-primary/10">
                    <File className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(file.size)}
                    </p>
                  </div>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemoveFile(index)}
                  className="h-8 w-8 text-muted-foreground hover:text-destructive flex-shrink-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              </motion.div>
            ))}
          </div>
          
          {uploadEndpoint && !autoUpload && (
            <div className="flex justify-end gap-2 pt-2">
              <Button
                type="button"
                onClick={uploadFiles}
                disabled={uploading || files.length === 0}
                className="shadow-md hover:shadow-lg transition-shadow"
              >
                <Upload className="h-4 w-4 mr-2" />
                Enviar Arquivo{files.length > 1 ? 's' : ''}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}