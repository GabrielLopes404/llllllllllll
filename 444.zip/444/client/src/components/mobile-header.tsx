import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ChevronLeft } from 'lucide-react';
import { useLocation } from 'wouter';

interface MobileHeaderProps {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  showBack?: boolean;
  className?: string;
}

export function MobileHeader({ 
  title, 
  subtitle, 
  actions, 
  showBack,
  className 
}: MobileHeaderProps) {
  const [, setLocation] = useLocation();

  return (
    <div className={cn(
      "flex flex-col gap-3 sm:gap-4 mb-4 sm:mb-6",
      className
    )}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-2 sm:gap-3 min-w-0 flex-1">
          {showBack && (
            <Button
              variant="ghost"
              size="icon"
              className="shrink-0 h-9 w-9 sm:h-10 sm:w-10"
              onClick={() => setLocation('/dashboard')}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
          )}
          <div className="min-w-0 flex-1">
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold truncate">
              {title}
            </h1>
            {subtitle && (
              <p className="text-sm sm:text-base text-muted-foreground mt-1 line-clamp-2">
                {subtitle}
              </p>
            )}
          </div>
        </div>
        {actions && (
          <div className="flex gap-2 shrink-0">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}
