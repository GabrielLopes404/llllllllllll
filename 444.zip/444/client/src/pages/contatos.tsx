import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Plus, 
  Search, 
  Mail,
  Phone,
  Building2,
  MoreHorizontal,
  Edit,
  Trash
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { pageVariants, staggerContainer, fadeInUp, headerVariants, buttonHover } from "@/lib/animations";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Contatos() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterTipo, setFilterTipo] = useState<string>("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const { data: contatos = [] } = useQuery({
    queryKey: ["/api/contatos"],
  });

  const createContatoMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/contatos", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contatos"] });
      setIsCreateDialogOpen(false);
      toast({ title: "Contato criado com sucesso!" });
    },
  });

  const deleteContatoMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/contatos/${id}`, undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contatos"] });
      toast({ title: "Contato excluído com sucesso!" });
    },
  });

  const handleCreateContato = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    createContatoMutation.mutate({
      tipo: formData.get("tipo"),
      nome: formData.get("nome"),
      email: formData.get("email") || null,
      telefone: formData.get("telefone") || null,
      cpfCnpj: formData.get("cpfCnpj") || null,
      empresa: formData.get("empresa") || null,
      endereco: formData.get("endereco") || null,
      cidade: formData.get("cidade") || null,
      estado: formData.get("estado") || null,
      cep: formData.get("cep") || null,
      observacoes: formData.get("observacoes") || null,
    });
    e.currentTarget.reset();
  };

  const handleDelete = (id: string) => {
    if (confirm("Deseja realmente excluir este contato?")) {
      deleteContatoMutation.mutate(id);
    }
  };

  const filteredContatos = contatos.filter((contato: any) => {
    const matchesSearch = contato.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (contato.empresa && contato.empresa.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesTipo = filterTipo === "all" || contato.tipo === filterTipo;
    return matchesSearch && matchesTipo;
  });

  return (
    <motion.div 
      className="flex-1 space-y-4 sm:space-y-6 p-3 sm:p-4 md:p-6 bg-gradient-to-br from-background via-background to-primary/5"
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <motion.div 
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        variants={headerVariants}
      >
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary via-chart-2 to-chart-4 bg-clip-text text-transparent">
            Contatos
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">Gerencie clientes e fornecedores</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <motion.div variants={buttonHover} whileHover="hover" whileTap="tap">
              <Button data-testid="button-new-contact" className="w-full sm:w-auto shadow-lg hover:shadow-xl transition-shadow">
                <Plus className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                <span className="hidden xs:inline">Novo Contato</span>
                <span className="xs:hidden">Novo</span>
              </Button>
            </motion.div>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Novo Contato</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateContato} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="tipo">Tipo</Label>
                  <select id="tipo" name="tipo" required className="w-full rounded-md border border-input bg-background px-3 py-2">
                    <option value="cliente">Cliente</option>
                    <option value="fornecedor">Fornecedor</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="nome">Nome *</Label>
                  <Input id="nome" name="nome" required />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">E-mail</Label>
                  <Input id="email" name="email" type="email" />
                </div>
                <div>
                  <Label htmlFor="telefone">Telefone</Label>
                  <Input id="telefone" name="telefone" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="cpfCnpj">CPF/CNPJ</Label>
                  <Input id="cpfCnpj" name="cpfCnpj" />
                </div>
                <div>
                  <Label htmlFor="empresa">Empresa</Label>
                  <Input id="empresa" name="empresa" />
                </div>
              </div>
              <div>
                <Label htmlFor="endereco">Endereço</Label>
                <Input id="endereco" name="endereco" />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="cidade">Cidade</Label>
                  <Input id="cidade" name="cidade" />
                </div>
                <div>
                  <Label htmlFor="estado">Estado</Label>
                  <Input id="estado" name="estado" maxLength={2} />
                </div>
                <div>
                  <Label htmlFor="cep">CEP</Label>
                  <Input id="cep" name="cep" />
                </div>
              </div>
              <div>
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea id="observacoes" name="observacoes" rows={3} />
              </div>
              <Button type="submit" className="w-full">Criar Contato</Button>
            </form>
          </DialogContent>
        </Dialog>
      </motion.div>

      <motion.div variants={fadeInUp}>
        <Card className="border-2 border-primary/20 hover:border-primary/40 transition-all shadow-lg backdrop-blur-sm bg-card/95">
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle className="text-lg sm:text-xl">Todos os Contatos</CardTitle>
            <div className="flex flex-wrap gap-2">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 h-3 w-3 sm:h-4 sm:w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar contatos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 sm:pl-9 text-xs sm:text-sm"
                  data-testid="input-search-contacts"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={filterTipo === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterTipo("all")}
                  data-testid="filter-all"
                  className="text-xs sm:text-sm"
                >
                  Todos
                </Button>
                <Button
                  variant={filterTipo === "cliente" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterTipo("cliente")}
                  data-testid="filter-clients"
                  className="text-xs sm:text-sm"
                >
                  Clientes
                </Button>
                <Button
                  variant={filterTipo === "fornecedor" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterTipo("fornecedor")}
                  data-testid="filter-suppliers"
                  className="text-xs sm:text-sm"
                >
                  Fornecedores
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <motion.div 
            className="grid gap-3 sm:gap-4 md:grid-cols-2 lg:grid-cols-3"
            variants={staggerContainer}
          >
            {filteredContatos.map((contato: any) => (
              <motion.div key={contato.id} variants={fadeInUp}>
                <Card className="border-2 border-primary/10 hover:border-primary/30 transition-all shadow-md hover:shadow-lg" data-testid={`contact-card-${contato.id}`}>
                <CardContent className="p-4 sm:p-6">
                  <div className="flex items-start justify-between mb-3 sm:mb-4">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <Avatar className="h-8 w-8 sm:h-10 sm:w-10">
                        <AvatarFallback className="bg-primary text-primary-foreground text-xs sm:text-sm">
                          {contato.nome.split(' ').map((n: string) => n[0]).join('').slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-sm sm:text-base">{contato.nome}</h3>
                        <Badge variant={contato.tipo === 'cliente' ? 'default' : 'secondary'} className="text-xs">
                          {contato.tipo === 'cliente' ? 'Cliente' : 'Fornecedor'}
                        </Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7 sm:h-8 sm:w-8">
                          <MoreHorizontal className="h-3 w-3 sm:h-4 sm:w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(contato.id)}>
                          <Trash className="h-4 w-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {contato.empresa && (
                    <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground mb-2">
                      <Building2 className="h-3 w-3 sm:h-4 sm:w-4" />
                      <span className="truncate">{contato.empresa}</span>
                    </div>
                  )}

                  {contato.email && (
                    <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground mb-2">
                      <Mail className="h-3 w-3 sm:h-4 sm:w-4" />
                      <span className="truncate">{contato.email}</span>
                    </div>
                  )}

                  {contato.telefone && (
                    <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                      <Phone className="h-3 w-3 sm:h-4 sm:w-4" />
                      <span>{contato.telefone}</span>
                    </div>
                  )}
                </CardContent>
              </Card>
              </motion.div>
            ))}
            {filteredContatos.length === 0 && (
              <div className="col-span-full text-center py-12">
                <p className="text-muted-foreground">Nenhum contato encontrado</p>
                <Button variant="link" onClick={() => setIsCreateDialogOpen(true)}>
                  Criar primeiro contato
                </Button>
              </div>
            )}
          </motion.div>
        </CardContent>
      </Card>
      </motion.div>
    </motion.div>
  );
}
