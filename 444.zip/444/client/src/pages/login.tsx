import { useState } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Lock, User, Eye, EyeOff, ArrowRight, Shield } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: "Login realizado!",
          description: "Bem-vindo ao sistema.",
        });

        if (data.user.role === "admin") {
          setLocation("/admin/dashboard");
        } else {
          setLocation("/dashboard");
        }
      } else {
        toast({
          title: "Erro no login",
          description: data.message || "Credenciais inválidas",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao conectar com o servidor",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen min-h-[100dvh] flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-4 relative overflow-hidden">
      {/* Grid Pattern Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:40px_40px]" />
      
      {/* Animated Gradient Orbs */}
      <motion.div
        className="absolute top-20 left-20 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.3, 0.5, 0.3],
          x: [0, 30, 0],
          y: [0, -20, 0],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-20 right-20 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-3xl"
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.2, 0.4, 0.2],
          x: [0, -40, 0],
          y: [0, 30, 0],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-pink-600/8 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.15, 1],
          opacity: [0.15, 0.3, 0.15],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
      />

      {/* Main Login Card - MESMA LARGURA PARA PC E MOBILE */}
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="w-full max-w-[400px] relative z-10"
      >
        {/* Glass Card Ultra Profissional */}
        <Card className="border-2 border-white/10 bg-slate-900/40 backdrop-blur-3xl shadow-[0_8px_32px_0_rgba(139,92,246,0.2)] rounded-[2rem] overflow-hidden">
          {/* Gradient Border Effect */}
          <div className="absolute inset-0 rounded-[2rem] bg-gradient-to-br from-violet-500/20 via-purple-500/20 to-pink-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
          
          <CardHeader className="space-y-3 pb-4 pt-8 px-6 relative">
            {/* Logo Icon com Efeito Holográfico */}
            <motion.div
              className="flex justify-center mb-2"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200, damping: 20, delay: 0.1 }}
            >
              <div className="relative group">
                {/* Glow Effect */}
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-tr from-violet-500 via-purple-500 to-pink-500 rounded-[1.2rem] blur-xl opacity-60"
                  animate={{
                    opacity: [0.4, 0.7, 0.4],
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />
                {/* Icon Container */}
                <div className="relative flex items-center justify-center h-16 w-16 rounded-[1.2rem] bg-gradient-to-tr from-violet-600 via-purple-600 to-pink-600 shadow-lg shadow-purple-500/50">
                  <Shield className="h-8 w-8 text-white drop-shadow-lg" strokeWidth={2.5} />
                </div>
              </div>
            </motion.div>

            {/* Title & Subtitle */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.4 }}
              className="text-center space-y-1"
            >
              <CardTitle className="text-3xl font-bold tracking-tight">
                <span className="bg-gradient-to-r from-white via-violet-100 to-purple-100 bg-clip-text text-transparent">
                  Lucrei
                </span>
              </CardTitle>
              <CardDescription className="text-sm text-slate-400">
                Faça login para continuar
              </CardDescription>
            </motion.div>
          </CardHeader>

          <CardContent className="pb-6 px-6">
            <form onSubmit={handleLogin} className="space-y-4">
              {/* Username Field */}
              <motion.div
                className="space-y-2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3, duration: 0.4 }}
              >
                <Label htmlFor="username" className="text-slate-300 text-sm font-medium">
                  Usuário
                </Label>
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-r from-violet-500/10 to-purple-500/10 rounded-xl opacity-0 group-focus-within:opacity-100 transition-opacity duration-300 blur" />
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500 transition-all duration-300 group-focus-within:text-violet-400 group-focus-within:scale-110 z-10" />
                  <Input
                    id="username"
                    type="text"
                    autoComplete="username"
                    placeholder="Digite seu usuário"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="h-12 pl-11 pr-4 bg-slate-800/50 border-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-violet-500/80 focus:ring-2 focus:ring-violet-500/30 transition-all duration-300 rounded-xl text-base shadow-inner relative"
                    required
                  />
                </div>
              </motion.div>

              {/* Password Field */}
              <motion.div
                className="space-y-2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.35, duration: 0.4 }}
              >
                <Label htmlFor="password" className="text-slate-300 text-sm font-medium">
                  Senha
                </Label>
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-xl opacity-0 group-focus-within:opacity-100 transition-opacity duration-300 blur" />
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500 transition-all duration-300 group-focus-within:text-purple-400 group-focus-within:scale-110 z-10" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    placeholder="Digite sua senha"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-12 pl-11 pr-12 bg-slate-800/50 border-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500/80 focus:ring-2 focus:ring-purple-500/30 transition-all duration-300 rounded-xl text-base shadow-inner relative"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-purple-400 transition-all duration-300 z-10 p-1 hover:scale-110"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </motion.div>

              {/* Forgot Password */}
              <motion.div
                className="flex justify-end"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                <Link href="/recuperar-senha">
                  <button type="button" className="text-sm text-slate-400 hover:text-violet-400 transition-colors duration-300 hover:underline underline-offset-2">
                    Esqueceu a senha?
                  </button>
                </Link>
              </motion.div>

              {/* Login Button Ultra Profissional */}
              <motion.div
                className="pt-2"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.45, duration: 0.4 }}
              >
                <div className="relative group">
                  {/* Button Glow Effect */}
                  <motion.div 
                    className="absolute inset-0 bg-gradient-to-r from-violet-600 via-purple-600 to-pink-600 rounded-xl blur-lg opacity-50 group-hover:opacity-75 transition-opacity duration-300"
                    animate={{
                      opacity: [0.5, 0.7, 0.5],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  />
                  <Button
                    type="submit"
                    className="relative w-full h-12 bg-gradient-to-r from-violet-600 via-purple-600 to-pink-600 hover:from-violet-500 hover:via-purple-500 hover:to-pink-500 text-white font-semibold shadow-xl shadow-purple-500/30 transition-all duration-300 rounded-xl group text-base hover:scale-[1.02] active:scale-[0.98]"
                    disabled={isLoading}
                  >
                    <AnimatePresence mode="wait">
                      {isLoading ? (
                        <motion.div
                          key="loading"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="flex items-center gap-2"
                        >
                          <motion.div
                            className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full"
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                          />
                          Entrando...
                        </motion.div>
                      ) : (
                        <motion.span
                          key="login"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="flex items-center gap-2"
                        >
                          Entrar
                          <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </Button>
                </div>
              </motion.div>

              {/* Divider */}
              <motion.div
                className="relative py-3"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-700/50"></div>
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-slate-900/40 px-3 text-slate-500">ou</span>
                </div>
              </motion.div>

              {/* Create Account */}
              <motion.div
                className="text-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.55 }}
              >
                <p className="text-sm text-slate-400">
                  Não tem uma conta?{" "}
                  <Link href="/registro">
                    <span className="font-semibold text-violet-400 hover:text-violet-300 transition-colors duration-300 cursor-pointer hover:underline underline-offset-2">
                      Criar conta
                    </span>
                  </Link>
                </p>
              </motion.div>

              {/* Demo Credentials - Ultra Professional */}
              <motion.div
                className="pt-2"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6, duration: 0.4 }}
              >
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-to-r from-violet-500/10 via-purple-500/10 to-pink-500/10 rounded-2xl blur opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="relative bg-slate-800/30 border border-slate-700/30 rounded-2xl p-4 backdrop-blur-sm">
                    <div className="text-center space-y-2">
                      <p className="text-xs font-medium text-slate-400 uppercase tracking-wider flex items-center justify-center gap-2">
                        <Shield className="h-3.5 w-3.5" />
                        Demonstração
                      </p>
                      <div className="flex items-center justify-center gap-2 text-sm">
                        <span className="font-mono font-bold text-violet-400 bg-violet-500/10 px-3 py-1 rounded-lg">admin</span>
                        <span className="text-slate-600">/</span>
                        <span className="font-mono font-bold text-purple-400 bg-purple-500/10 px-3 py-1 rounded-lg">admin123</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </form>
          </CardContent>
        </Card>

        {/* Security Badge */}
        <motion.div
          className="mt-6 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.65 }}
        >
          <div className="flex items-center justify-center gap-2 text-xs text-slate-500">
            <Shield className="h-3.5 w-3.5" />
            <span>Protegido com criptografia de ponta</span>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
