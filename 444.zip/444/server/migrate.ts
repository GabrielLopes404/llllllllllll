import { db } from './db';
import { sql } from 'drizzle-orm';
import { users, contas, faturas, contatos, fluxoCaixa, conciliacoes } from '@shared/schema';
import bcrypt from 'bcryptjs';

async function migrate() {
  console.log('🔄 Criando tabelas...');

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS users (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
      username TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      email TEXT,
      full_name TEXT,
      phone TEXT,
      company TEXT,
      cnpj TEXT,
      position TEXT,
      department TEXT,
      address TEXT,
      address_number TEXT,
      complement TEXT,
      neighborhood TEXT,
      zip_code TEXT,
      city TEXT,
      state TEXT,
      bio TEXT,
      avatar TEXT,
      role TEXT NOT NULL DEFAULT 'user',
      is_active BOOLEAN NOT NULL DEFAULT true,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      last_login TIMESTAMP,
      preferences TEXT
    )
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contas (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id VARCHAR NOT NULL,
      tipo TEXT NOT NULL,
      descricao TEXT NOT NULL,
      valor DECIMAL(10, 2) NOT NULL,
      data_vencimento TIMESTAMP NOT NULL,
      data_pagamento TIMESTAMP,
      status TEXT NOT NULL DEFAULT 'pendente',
      categoria TEXT,
      contato_id VARCHAR,
      observacoes TEXT,
      anexo TEXT,
      recorrente BOOLEAN DEFAULT false,
      periodicidade TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS faturas (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id VARCHAR NOT NULL,
      numero TEXT NOT NULL,
      contato_id VARCHAR NOT NULL,
      data_emissao TIMESTAMP NOT NULL,
      data_vencimento TIMESTAMP NOT NULL,
      valor DECIMAL(10, 2) NOT NULL,
      desconto DECIMAL(10, 2) DEFAULT 0,
      valor_total DECIMAL(10, 2) NOT NULL,
      status TEXT NOT NULL DEFAULT 'emitida',
      observacoes TEXT,
      itens TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS contatos (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id VARCHAR NOT NULL,
      tipo TEXT NOT NULL,
      nome TEXT NOT NULL,
      email TEXT,
      telefone TEXT,
      cpf_cnpj TEXT,
      empresa TEXT,
      endereco TEXT,
      cidade TEXT,
      estado TEXT,
      cep TEXT,
      observacoes TEXT,
      ativo BOOLEAN DEFAULT true,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS fluxo_caixa (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id VARCHAR NOT NULL,
      data TIMESTAMP NOT NULL,
      tipo TEXT NOT NULL,
      categoria TEXT NOT NULL,
      descricao TEXT NOT NULL,
      valor DECIMAL(10, 2) NOT NULL,
      saldo DECIMAL(10, 2) NOT NULL,
      referencia TEXT,
      referencia_id VARCHAR,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS conciliacoes (
      id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id VARCHAR NOT NULL,
      data_inicio TIMESTAMP NOT NULL,
      data_fim TIMESTAMP NOT NULL,
      banco TEXT NOT NULL,
      conta TEXT NOT NULL,
      saldo_inicial DECIMAL(10, 2) NOT NULL,
      saldo_final DECIMAL(10, 2) NOT NULL,
      total_entradas DECIMAL(10, 2) NOT NULL,
      total_saidas DECIMAL(10, 2) NOT NULL,
      status TEXT NOT NULL DEFAULT 'em_progresso',
      observacoes TEXT,
      transacoes TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `);

  console.log('✅ Tabelas criadas com sucesso!');

  console.log('🔄 Criando usuário admin...');
  try {
    const hashedPassword = await bcrypt.hash('admin123', 10);
    await db.execute(sql`
      INSERT INTO users (username, password, email, full_name, role, is_active)
      VALUES ('admin', ${hashedPassword}, 'admin@lucrei.com', 'Administrador', 'admin', true)
      ON CONFLICT (username) DO NOTHING
    `);
    console.log('✅ Usuário admin configurado (username: admin, password: admin123)');
  } catch (error: any) {
    if (error.message?.includes('duplicate') || error.message?.includes('already exists')) {
      console.log('ℹ️  Usuário admin já existe');
    } else {
      throw error;
    }
  }

  console.log('🎉 Migração concluída!');
}

migrate()
  .catch((error) => {
    console.error('❌ Erro na migração:', error);
    process.exit(1);
  })
  .finally(() => {
    process.exit(0);
  });
